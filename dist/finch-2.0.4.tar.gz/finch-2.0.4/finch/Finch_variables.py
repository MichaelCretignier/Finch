from pathlib import Path

BASE_DIR = str(Path(__file__).resolve().parent)
TEST_DIR = BASE_DIR + "/test_dataset"
test_file = TEST_DIR + "/Finch_input_HD128621.csv"
sun_file = TEST_DIR + "/Solar_Mg2.csv"